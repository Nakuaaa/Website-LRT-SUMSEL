<?php
include '../kuisoner/config.php'; // Pastikan file ini benar-benar terhubung ke database

// Ambil data visimisi dari database
$query = "SELECT visimisi FROM tentang WHERE id_tentang=11";
$result = $conn->query($query);
$visimisiData = $result->fetch_assoc();
$visimisiImg = $visimisiData['visimisi'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visi Misi</title>
    <link rel="stylesheet" href="../tentang kami/sejarah.css?v=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(231deg, #B0BAC0 4.52%, #D9ECF4 12.34%, #E3DAC5 94.39%, #FFF 112.85%);
        }
    </style>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
        }
        h2 {
            color: #601212;
            text-align: center;
            font-size: 24px;
            background: linear-gradient(90deg, #91CFE9 0%, #B0BAC0 100%);
            box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25), 0px 4px 4px 0px rgba(0, 0, 0, 0.25), 0px 4px 4px 0px rgba(0, 0, 0, 0.25), 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
            text-shadow: #0045bf;
        }
        .contact-section {
            padding: 20px;
            max-width: 850px;
            margin: auto;
        }
        
        .contact-section h2 {
            margin-bottom: 50px;
            text-align: center;
        }
        
        .contact-container {
            display: flex;
            justify-content: space-between;
        }
        
        .contact-column {
            width: 38%;
        }
        
        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .contact-item i {
            margin-right: 15px;
            font-size: 1.5em;
        }
        
        .contact-item a {
            color: #ffffff;
            text-decoration: none;
            transition: color 0.3s ease; /* Add transition for smooth effect */
        }
    
        /* Hover effect */
        .contact-item a:hover {
            color: #000000; /* Change color to black on hover */
        }
    </style>
</head>
<body>
    <!-- bagian navbar -->
    <header>
        <nav>
            <div class="nav-left" style="font-family: intim;">
                <a href="../beranda/beranda1.html">Beranda</a>
                <div class="dropdown">
                    <a href="#"  class="active" <button class="dropbtn">Tentang Kami<span class="arrow-down"></span></button> </a>
                    <div class="dropdown-content">
                        <a href="../tentang kami/sejarah.php">Sejarah</a>
                        <a href="#">Visi dan Misi</a>
                        <a href="../tentang kami/struktur.php">Struktur</a>
                    </div>
                </div>
                <a href="../survei/survei.php">Survei</a>
                <a href="../Diagram/diagram.php">Diagram</a>
                <a href="../berita/berita.php">Galeri</a>
            </div>
            <div class="nav-right" style="font-family: intim;">
                <a href="../kuisoner/login.php" class="btn" target="_blank">Login Now</a>
            </div>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header>

    <br><br><br><br><br><br><br><br>
    <div class="container">
        <div class="map" id="idMap">
            <?php if (!empty($visimisiImg)): ?>
                <img src="<?= htmlspecialchars($visimisiImg) ?>" alt="Visi Misi" style="width: 820px; height: 1000px;">
            <?php else: ?>
                <p>Gambar Visi Misi belum diupload.</p>
            <?php endif; ?>
        </div>
    </div>
    <br><br><br><br><br><br><br>

     <div class="footer-separator"></div>
            <div class="container" style="font-family: Intim;">
                <div class="footer">

                    <div class="contact-section">
                            <h2>KONTAK KAMI</h2>
                            <div class="contact-container">
                                <div class="contact-column">

                                    <!--Map-->
                                    <div class="contact-item">
                                        <a href="https://maps.app.goo.gl/pAXkCKnZRET83XRq6">
                                            <i class="fas fa-map-marker-alt"></i>
                                            </a>
                                        <div>
                                            <a href="https://maps.app.goo.gl/pAXkCKnZRET83XRq6">
                                            <strong>Kantor Pusat:</strong> 
                                            Jl. H.M. Noerdin Pandji, RT.11/RW.03, Jakabaring Selatan, Kec. Rambutan,
                                            Kab. Banyuasin, Sumatera Selatan 30967
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <!--Website-->
                                    <div class="contact-item">
                                        <a href="https://djka.dephub.go.id/">
                                            <i class="fas fa-globe"></i>
                                        </a>
                                        <div>
                                            <a href="https://djka.dephub.go.id/">
                                            <strong>Website:</strong> djka.dephub.go.id
                                            </a>
                                        </div>
                                    </div>

                                    <!--No Telepon-->
                                    <div class="contact-item">
                                        <a href="#">
                                            <i class="fas fa-phone"></i>
                                        </a>
                                        <div>
                                            <a href="#">
                                            <strong>No Telepon:</strong> 0711-5542499
                                            </a>
                                        </div>
                                    </div>

                                    <!--Email-->
                                    <div class="contact-item">
                                        <a href="../beranda/beranda1.html">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                        <div>
                                            <a href="../beranda/beranda1.html">
                                            <strong>Email:</strong> Balailrtsumsel@dephub.go.id
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <!--Instagram-->
                                <div class="contact-column">
                                    <div class="contact-item">
                                        <a href="https://www.instagram.com/lrtsumselofficial?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.instagram.com/lrtsumselofficial?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==">
                                            <strong>Instagram:</strong> @lrtsumselofficial
                                            </a>
                                        </div>
                                    </div>

                                    <!--Youtube-->
                                    <div class="contact-item">
                                        <a href="https://www.youtube.com/@lrtsumsel4659">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.youtube.com/@lrtsumsel4659">
                                            <strong>Youtube:</strong> @lrtsumsel4569
                                            </a>
                                        </div>
                                    </div>

                                    <!--Facebook-->
                                    <div class="contact-item">
                                        <a href="https://www.facebook.com/profile.php?id=100070323324622">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.facebook.com/profile.php?id=100070323324622">
                                            <strong>Facebook:</strong> @Balai Pengelola
                                            </a>
                                        </div>
                                    </div>

                                    <!--twitter-->
                                    <div class="contact-item">
                                        <a href="https://x.com/LrtSumsel">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                        <div>
                                            <a href="https://x.com/LrtSumsel">
                                            <strong>Twitter:</strong> @LrtSumsel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <script src="sejarah.js"></script>
</body>
</html>
