<?php
session_start();
include 'config.php';

if (!isset($_SESSION['nama_admin'])) {
    header("Location: login.php");
    exit();
}

// Inisialisasi variabel untuk input form
$id_ikm = '';
$nilai = '';
$bulan = '';
$tahun = '';

// Cek apakah sedang dalam mode edit
if (isset($_GET['edit_id'])) {
    $id_ikm = $_GET['edit_id'];
    $sql_edit = "SELECT * FROM IKM WHERE id_ikm = ?";
    $stmt_edit = $conn->prepare($sql_edit);
    $stmt_edit->bind_param("i", $id_ikm);
    $stmt_edit->execute();
    $result_edit = $stmt_edit->get_result();
    if ($row_edit = $result_edit->fetch_assoc()) {
        $nilai = $row_edit['nilai'];
        $bulan = $row_edit['bulan'];
        $tahun = $row_edit['tahun'];
    }
    $stmt_edit->close();
}

// Proses input atau update data IKM
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nilai = $_POST['nilai'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    
    if (!empty($_POST['id_ikm'])) {
        // Update data IKM
        $id_ikm = $_POST['id_ikm'];
        $sql_update = "UPDATE IKM SET nilai = ?, bulan = ?, tahun = ? WHERE id_ikm = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("diii", $nilai, $bulan, $tahun, $id_ikm);
        $stmt_update->execute();
        $stmt_update->close();
    } else {
        // Input data IKM baru
        $sql_insert = "INSERT INTO IKM (nilai, bulan, tahun) VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("dii", $nilai, $bulan, $tahun);
        $stmt_insert->execute();
        $stmt_insert->close();
    }
    
    header("Location: input_ikm.php");
    exit();
}

// Ambil data IKM untuk ditampilkan dalam tabel
$sql_ikm = "SELECT * FROM IKM ORDER BY tahun DESC, bulan DESC";
$ikm_result = $conn->query($sql_ikm);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Indeks Kepuasan Masyarakat</title>
    <link rel="stylesheet" href="style_pertanyaan.css">
</head>
<body>
    <div class="navbar">
        <a href="crud_pertanyaan.php">Kelola Pertanyaan</a>
        <a href="crud_berita.php">Kelola Galeri</a>
        <a href="crud_tentang.php">Kelola Tentang</a>
        <a href="view_survey.php">Lihat Survey</a>
        <a href="crud_kelPert.php">Kelola Kel Pertanyaan</a>
        <a href="crud_admin.php">Kelola Admin</a>
        <a href="input_ikm.php">Input IKM</a>
        <a href="../beranda/beranda1.html">Logout</a>
    </div>
    
    <h2>Input Indeks Kepuasan Masyarakat</h2>
    
    <form method="post" action="">
        <input type="hidden" name="id_ikm" value="<?php echo htmlspecialchars($id_ikm); ?>">
        
        <label for="nilai">Nilai IKM:</label>
        <input type="number" step="0.01" name="nilai" id="nilai" value="<?php echo htmlspecialchars($nilai); ?>" required>
        
        <label for="bulan">Bulan:</label>
        <select name="bulan" id="bulan" required>
            <option value="1" <?php if ($bulan == 1) echo 'selected'; ?>>Januari</option>
            <option value="2" <?php if ($bulan == 2) echo 'selected'; ?>>Februari</option>
            <option value="3" <?php if ($bulan == 3) echo 'selected'; ?>>Maret</option>
            <option value="4" <?php if ($bulan == 4) echo 'selected'; ?>>April</option>
            <option value="5" <?php if ($bulan == 5) echo 'selected'; ?>>Mei</option>
            <option value="6" <?php if ($bulan == 6) echo 'selected'; ?>>Juni</option>
            <option value="7" <?php if ($bulan == 7) echo 'selected'; ?>>Juli</option>
            <option value="8" <?php if ($bulan == 8) echo 'selected'; ?>>Agustus</option>
            <option value="9" <?php if ($bulan == 9) echo 'selected'; ?>>September</option>
            <option value="10" <?php if ($bulan == 10) echo 'selected'; ?>>Oktober</option>
            <option value="11" <?php if ($bulan == 11) echo 'selected'; ?>>November</option>
            <option value="12" <?php if ($bulan == 12) echo 'selected'; ?>>Desember</option>
        </select>
        
        <label for="tahun">Tahun:</label>
        <input type="number" name="tahun" id="tahun" value="<?php echo htmlspecialchars($tahun); ?>" required>
        
        <button type="submit"><?php echo empty($id_ikm) ? 'Simpan' : 'Update'; ?></button>
    </form>
    
    <h3>Daftar Indeks Kepuasan Masyarakat</h3>
    <table>
        <thead>
            <tr>
                <th>ID IKM</th>
                <th>Nilai</th>
                <th>Bulan</th>
                <th>Tahun</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $ikm_result->fetch_assoc()) : ?>
            <tr>
                <td><?php echo $row['id_ikm']; ?></td>
                <td><?php echo $row['nilai']; ?></td>
                <td><?php echo date("F", mktime(0, 0, 0, $row['bulan'], 1)); ?></td>
                <td><?php echo $row['tahun']; ?></td>
                <td><a href="input_ikm.php?edit_id=<?php echo $row['id_ikm']; ?>">Edit</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>