<?php
include '../kuisoner/config.php';

// Mengurutkan berita berdasarkan timestamp dalam urutan menurun
$sql = "SELECT * FROM berita ORDER BY timestamp DESC";
$berita = $conn->query($sql);
$all_berita = [];
while ($row = $berita->fetch_assoc()) {
    $all_berita[] = $row;
}
$total_berita = count($all_berita);
$items_per_page = 4;
$total_pages = ceil($total_berita / $items_per_page);
?>

<!DOCTYPE html>
<html>

<head>
  <title>Galeri</title>
  <link rel="stylesheet" type="text/css" href="../kuisoner/style_berita.css">
  <link rel="stylesheet" href="../beranda/beranda1.css">
  <link rel="stylesheet" href="../berita/berita1.css?v=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap"
      rel="stylesheet"

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />

</head>

<body>

<!-- bagian navbar -->
<header>
        <nav>
            <div class="nav-left" style="font-family: intim;">
                <a href="../beranda/beranda1.html">Beranda</a>
                <div class="dropdown">
                    <a href="#" <button class="dropbtn">Tentang Kami<span class="arrow-down"></span></button> </a>
                    <div class="dropdown-content">
                        <a href="../tentang kami/sejarah.php">Sejarah</a>
                        <a href="../tentang kami/visimisi.php">Visi dan Misi</a>
                        <a href="../tentang kami/struktur.php">Struktur</a>
                    </div>
                </div>
                <a href="../survei/survei.php">Survei</a>
                <a href="../Diagram/diagram.php">Diagram</a>
                <a href="../berita/berita.php" class="active">Galeri</a>
            </div>
            <div class="nav-right" style="font-family: intim;">
            <a href="../kuisoner/login.php" class="btn" target="_blank">Login Now</a>
            </div>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header><br>
    
  <h2>Galeri & Berita</h2>
  <div class="gallery-container">
    <div class="gallery-wrapper">
      <?php for ($i = 0; $i < $total_pages; $i++) : ?>
        <div class="gallery-page">
          <?php for ($j = $i * $items_per_page; $j < ($i + 1) * $items_per_page && $j < $total_berita; $j++) : ?>
            <div class="gallery-item">
              <?php if (!empty($all_berita[$j]['gambar'])) : ?>
                <img src="../kuisoner/uploads/<?php echo $all_berita[$j]['gambar']; ?>" alt="<?php echo $all_berita[$j]['judul']; ?>" class="gallery-image">
              <?php endif; ?>
              <div class="gallery-content" id="title">
                <h3><?php echo $all_berita[$j]['judul']; ?></h3>
                <p class="timestamp">Waktu: <?php echo $all_berita[$j]['timestamp']; ?></p>
                <div class="zz">
                <p class="short-text">
                  <?php 
                    echo substr($all_berita[$j]['isi'], 0, 100); 
                    if (strlen($all_berita[$j]['isi']) > 100) {
                      echo '...';
                    }
                  ?>
                </p>
                </div>
                <?php if (strlen($all_berita[$j]['isi']) > 100) : ?>
                  <p class="full-text" style="display: none;"><?php echo $all_berita[$j]['isi']; ?></p>
                  <a href="javascript:void(0);" class="toggle-text">Baca selanjutnya</a>
                <?php endif; ?>
              </div>
            </div>
          <?php endfor; ?>
        </div>
      <?php endfor; ?>
    </div>
    <button class="prev">&lt;</button>
    <button class="next">&gt;</button>
  </div>

  <script src="../berita/script.js"></script>
</body>

</html>