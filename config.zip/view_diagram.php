<?php
session_start();
include '../kuisoner/config.php';

if (!isset($_SESSION['nama_admin'])) {
    header("Location: login.php");
    exit();
}

// Ambil data jumlah pelanggan laki-laki dan perempuan
$sql_gender = "SELECT jenis_kelamin, COUNT(*) as count FROM pelanggan GROUP BY jenis_kelamin";
$gender_result = $conn->query($sql_gender);

$gender_data = [
    'laki-laki' => 0,
    'perempuan' => 0
];

while ($row = $gender_result->fetch_assoc()) {
    if ($row['jenis_kelamin'] == 'laki-laki') {
        $gender_data['laki-laki'] = $row['count'];
    } elseif ($row['jenis_kelamin'] == 'perempuan') {
        $gender_data['perempuan'] = $row['count'];
    }
}

// Ambil data tujuan perjalanan
$sql_tujuan = "SELECT tujuan_perjalanan, COUNT(*) as count FROM pelanggan GROUP BY tujuan_perjalanan";
$tujuan_result = $conn->query($sql_tujuan);

$tujuan_data = [];
while ($row = $tujuan_result->fetch_assoc()) {
    $tujuan_data[$row['tujuan_perjalanan']] = $row['count'];
}

// Ambil data usia
$sql_usia = "SELECT usia, COUNT(*) as count FROM pelanggan GROUP BY usia";
$usia_result = $conn->query($sql_usia);

$usia_data = [];
while ($row = $usia_result->fetch_assoc()) {
    $usia_data[$row['usia']] = $row['count'];
}

// Ambil data frekuensi penggunaan
$sql_frekuensi = "SELECT frekuensi_penggunaan, COUNT(*) as count FROM pelanggan GROUP BY frekuensi_penggunaan";
$frekuensi_result = $conn->query($sql_frekuensi);

$frekuensi_data = [];
while ($row = $frekuensi_result->fetch_assoc()) {
    $frekuensi_data[$row['frekuensi_penggunaan']] = $row['count'];
}

// Ambil data opsi dan pertanyaan dari tabel pertanyaan
$sql_pertanyaan = "SELECT id_pertanyaan, pertanyaan, opsi FROM pertanyaan WHERE tipe_pertanyaan = 'multiple choice'";
$pertanyaan_result = $conn->query($sql_pertanyaan);

$pertanyaan_data = [];
while ($row = $pertanyaan_result->fetch_assoc()) {
    $pertanyaan_data[$row['id_pertanyaan']] = [
        'pertanyaan' => $row['pertanyaan'],
        'opsi' => explode(',', $row['opsi'])
    ];
}

// Ambil data nilai dari tabel hasil_perhitungan
$sql_hasil_perhitungan = "SELECT * FROM hasil_perhitungan";
$hasil_perhitungan_result = $conn->query($sql_hasil_perhitungan);

$hasil_perhitungan_data = [];
while ($row = $hasil_perhitungan_result->fetch_assoc()) {
    $hasil_perhitungan_data[$row['id_pertanyaan']] = [
        'nilai_1' => $row['nilai_1'],
        'nilai_2' => $row['nilai_2'],
        'nilai_3' => $row['nilai_3'],
        'nilai_4' => $row['nilai_4'],
        'nilai_5' => $row['nilai_5'],
        'nilai_6' => $row['nilai_6'],
        'nilai_7' => $row['nilai_7'],
        'nilai_8' => $row['nilai_8'],
        'nilai_9' => $row['nilai_9'],
        'nilai_10' => $row['nilai_10']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagram Hasil Survey</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style_viewdiagram.css?v=1.0">
</head>
<body>

    <h2>Diagram Hasil Survey</h2>
    

    <div class="chart-row">
        <div class="chart-container">
            <canvas id="genderChart"></canvas>
        </div>
        <div class="chart-container">
            <canvas id="tujuanChart"></canvas>
        </div>
    </div>
    <div class="chart-row">
        <div class="chart-container">
            <canvas id="usiaChart"></canvas>
        </div>
        <div class="chart-container">
            <canvas id="frekuensiChart"></canvas>
        </div>
    </div>

    <div class="chart-row">
        <?php foreach ($pertanyaan_data as $id_pertanyaan => $pertanyaan_info) : ?>
            <div class="chart-container">
                <canvas id="barChart<?php echo $id_pertanyaan; ?>"></canvas>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var rootStyles = getComputedStyle(document.documentElement);

            // Pie charts
            var genderCtx = document.getElementById('genderChart').getContext('2d');
            var genderChart = new Chart(genderCtx, {
                type: 'pie',
                data: {
                    labels: ['Laki-laki', 'Perempuan'],
                    datasets: [{
                        data: [<?php echo $gender_data['laki-laki']; ?>, <?php echo $gender_data['perempuan']; ?>],
                        backgroundColor: [rootStyles.getPropertyValue('--color1'), rootStyles.getPropertyValue('--color2')],
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Hasil Survey Berdasarkan Jenis Kelamin'
                        }
                    }
                },
            });

            var tujuanCtx = document.getElementById('tujuanChart').getContext('2d');
            var tujuanChart = new Chart(tujuanCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_keys($tujuan_data)); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_values($tujuan_data)); ?>,
                        backgroundColor: [
                            rootStyles.getPropertyValue('--color1'),
                            rootStyles.getPropertyValue('--color2'),
                            rootStyles.getPropertyValue('--color3'),
                            rootStyles.getPropertyValue('--color4'),
                            rootStyles.getPropertyValue('--color5'),
                            rootStyles.getPropertyValue('--color6')
                        ],
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Hasil Survey Berdasarkan Tujuan Perjalanan'
                        }
                    }
                },
            });

            var usiaCtx = document.getElementById('usiaChart').getContext('2d');
            var usiaChart = new Chart(usiaCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_keys($usia_data)); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_values($usia_data)); ?>,
                        backgroundColor: [
                            rootStyles.getPropertyValue('--color1'),
                            rootStyles.getPropertyValue('--color2'),
                            rootStyles.getPropertyValue('--color3'),
                            rootStyles.getPropertyValue('--color4'),
                            rootStyles.getPropertyValue('--color5'),
                            rootStyles.getPropertyValue('--color6')
                        ],
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Hasil Survey Berdasarkan Usia'
                        }
                    }
                },
            });

            var frekuensiCtx = document.getElementById('frekuensiChart').getContext('2d');
            var frekuensiChart = new Chart(frekuensiCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_keys($frekuensi_data)); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_values($frekuensi_data)); ?>,
                        backgroundColor: [
                            rootStyles.getPropertyValue('--color1'),
                            rootStyles.getPropertyValue('--color2'),
                            rootStyles.getPropertyValue('--color3'),
                            rootStyles.getPropertyValue('--color4'),
                            rootStyles.getPropertyValue('--color5'),
                            rootStyles.getPropertyValue('--color6')
                        ],
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Hasil Survey Berdasarkan Frekuensi Penggunaan'
                        }
                    }
                },
            });

            // Bar charts for each question
            <?php foreach ($pertanyaan_data as $id_pertanyaan => $pertanyaan_info) : ?>
                var barCtx<?php echo $id_pertanyaan; ?> = document.getElementById('barChart<?php echo $id_pertanyaan; ?>').getContext('2d');
                var barChart<?php echo $id_pertanyaan; ?> = new Chart(barCtx<?php echo $id_pertanyaan; ?>, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($pertanyaan_info['opsi']); ?>,
                        datasets: [{
                            label: '<?php echo $pertanyaan_info['pertanyaan']; ?>',
                            data: <?php
                                $data = [];
                                foreach ($pertanyaan_info['opsi'] as $index => $opsi) {
                                    $nilai_index = 'nilai_' . ($index + 1);
                                    $data[] = $hasil_perhitungan_data[$id_pertanyaan][$nilai_index] ?? 0;
                                }
                                echo json_encode($data);
                            ?>,
                            backgroundColor: [
                                rootStyles.getPropertyValue('--color1'),
                                rootStyles.getPropertyValue('--color2'),
                                rootStyles.getPropertyValue('--color3'),
                                rootStyles.getPropertyValue('--color4'),
                                rootStyles.getPropertyValue('--color5'),
                                rootStyles.getPropertyValue('--color6')
                            ],
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        },
                        plugins: {
                            legend: {
                                display: false,
                            },
                            title: {
                                display: true,
                                text: '<?php echo $pertanyaan_info['pertanyaan']; ?>'
                            }
                        }
                    },
                });
            <?php endforeach; ?>
        });
    </script>
<script src="../kuisoner/script.js"></script>
</body>
</html>

<?php
$conn->close();
?>
