<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sejarah</title>
    <link rel="stylesheet" href="sejarah.css">
    <link rel="stylesheet" href="sejarah1.css?v=1.0">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet" <link
        rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

    <style>
        table {
            width: 80%;
            /* Adjust this percentage as needed */
            margin: auto;
            border-collapse: collapse;
            table-layout: fixed;
        }

        th,
        td {
            border: 1px solid #000000;
            text-align: center;
            padding: 8px;
            word-wrap: break-word;
        }

        th {
            background: linear-gradient(90deg, #91CFE9 0%, #B0BAC0 100%);
        }

        .station-number {
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgb(0, 0, 0);
            border-radius: 50%;
            width: 100px;
            height: 100px;
            margin: auto;
        }

        td a {
            color: purple;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }
    </style>
    

</head>

<body>

    <?php include '../kuisoner/config.php'; ?>

    <?php
    $sql = "SELECT sejarah FROM tentang WHERE id_tentang = 11"; // Sesuaikan query ini sesuai dengan kebutuhan
    $result = $conn->query($sql);
    $sejarah = "";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $sejarah = $row["sejarah"];
        }
    } else {
        $sejarah = "Data sejarah tidak ditemukan.";
    }
    $conn->close();
    ?>
    <header>
        <nav>
            <div class="nav-left" style="font-family: intim;">
                <a href="../beranda/beranda1.html">Beranda</a>
                <div class="dropdown">
                    <a href="#"  class="active" <button class="dropbtn">Tentang Kami<span class="arrow-down"></span></button> </a>
                    <div class="dropdown-content">
                        <a href="#">Sejarah</a>
                        <a href="../tentang kami/visimisi.php">Visi dan Misi</a>
                        <a href="../tentang kami/struktur.php">Struktur</a>
                    </div>
                </div>
                <a href="../survei/survei.php">Survei</a>
                <a href="../Diagram/diagram.php">Diagram</a>
                <a href="../berita/berita.php">Galeri</a>
            </div>
            <div class="nav-right" style="font-family: intim;">
                <a href="../kuisoner/login.php" class="btn" target="_blank">Login Now</a>
            </div>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header>

    <div class="about" style="color: #2C2C2C">
        <div class="tentang">
            <h1 style="text-align: center;">
                <span class="sjrh" style="font-size: 40px;">Sejarah LRT Sumatera Selatan</span>
            </h1>
            <style style="align-items: center;">
                body {
                    background-image: url('../beranda/gambar/per.png');
                    background-repeat: no-repeat;
                    background-attachment: fixed;
                    width: 100%;
                    height: 100%;
                    align-items: center;
                }
            </style>
            <!-- <p style="text-align: left;">
                <b style="font-size: 20px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sejarah LRT Sumatera Selatan</b>
            </p> -->
            <div class="container">
                <div class="box">
                    <?php echo $sejarah; ?>
                    <a href="https://id.wikipedia.org/wiki/LRT_Sumatera_Selatan" target="_blank"><u>Baca Selengkapnya Disini.</u></a>
                </div>
            </div>
        </div>
    </div>

    <div style="color: #2C2C2C; margin-top: -10px;">
        <div class="rute" style="text-align: center;"><b>
                <span class="rutee" style="font-size: 40px;">Rute LRT Sumatera Selatan</span></b>
        </div>
        <div class="teks" style="font-family: Irian Sans;">
            <div style="line-height: 1.7;"><br>
                <p class="cpt" style="margin-top: 0px;">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proyek
                    transportasi Light Rail Transit (LRT) sedang dibangun di Palembang, Sumatera Selatan yang akan ada 5 Zona Rute yang dilewati oleh <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sarana transportasi yang dibuat untuk menyambut Asian Games 2018 ini. Akan ada 13 stasiun yang dibangun 
                    untuk LRT ini dengan panjang total proyek 23 <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kilometer (km). Kementerian Perhubungan menjadi penyelenggara proyek, sementara 
                   kontraktornya adalah PT Waskita Karya Tbk.
                </p>
            </div><br>
            <div class="map" id="idMap" style="text-align: right; margin-top: -80px;">
                <img src="../beranda/gambar/jalur.png" alt="" style="margin-top: -180px;">
            </div>

            <div style="color: #2C2C2C; margin-top: -190px;">
                <div class="rute" style="text-align: center;"><b><br><br>
                        <span class="rutee" style="font-size: 40px;">Stasiun LRT Sumatera Selatan</span></b>
                </div>
                <div class="teks" style="font-family: Irian Sans;">
                    <div style="line-height: 1.7;">
                        <p>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ada
                            13 stasiun pada jalur LRT ini dan 1 depot 12 stasiun di antaranya telah beroperasi sejak 6 Oktober 2018. Setiap rangkaian kereta akan berhenti <br>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;selama 1 menit di setiap stasiun, kecuali di setiap stasiun akhir perjalanan rangkaian kereta akan berhenti selama 10 
                            menit 5 di antara 13 stasiun yang ada <br>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;dilengkapi dengan jembatan penghubung dengan bangunan-bangunan di sekitarnya.
                        </p>
                    </div><br>

                    <table>
                        <tr>
                            <th>Nomor stasiun</th>
                            <th>Stasiun</th>
                            <th>Layanan Penghubung</th>
                            <th>Tempat terdekat</th>
                            <th>Keterangan</th>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 01</div>
                            </td>
                            <td>Bandara SMB II</td>
                            <td>
                                <p>Trans Musi: Koridor 5 <br>Teman Bus: -</p>
                            </td>
                            <td>Bandar Udara Internasional Sultan Mahmud Badaruddin II</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 02</div>
                            </td>
                            <td>Asrama Haji</td>
                            <td>
                                <p>Trans MUsi: Koridor 5 & 6 <br>Teman Bus: Koridor 4, 1F, 2F & 3F</p>
                            </td>
                            <td>Asrama Haji Palembang</td>
                            <td>Dibuka pada 7 September 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 03</div>
                            </td>
                            <td>Punti Kayu</td>
                            <td>
                                <p>Trans Musi: Koridor 1, 6 & 9 <br>Teman Bus: Koridor 1F</p>
                            </td>
                            <td>Punti Kayu, Gramedia World Palembang</td>
                            <td>Dibuka pada 24 September 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 04</div>
                            </td>
                            <td>RSUD</td>
                            <td>
                                <p>Trans Musi: Koridor 1, 6 & 9 <br>Teman Bus: Koridor 6F</p>
                            </td>
                            <td>RSUD Siti Fatimah</td>
                            <td>Dibuka pada 25 September 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 05</div>
                            </td>
                            <td>Garuda Dempo</td>
                            <td>
                                <p>Trans Musi: - <br>Teman Bus: -</p>
                            </td>
                            <td>Korem 044/Garuda Dempo</td>
                            <td>Dibuka pada 19 Oktober 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 06</div>
                            </td>
                            <td>Demang</td>
                            <td>
                                <p>Trans Musi: Koridor 2 <br>Teman Bus: Koridor 1 & 2</p>
                            </td>
                            <td>SMKN 2 Palembang</td>
                            <td>Dibuka pada 6 Oktober 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 07</div>
                            </td>
                            <td>Bumi Sriwijaya</td>
                            <td>
                                <p>Trans Musi: Koridor 3 & 7 <br>Teman Bus: Koridor 2, 3 & 7F</p>
                            </td>
                            <td>Palembang Icon, Stadion Bumi Sriwijaya</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 08</div>
                            </td>
                            <td>Dishub</td>
                            <td>
                                <p>Trans Musi: Koridor 7 <br>Teman Bus: Koridor 3</p>
                            </td>
                            <td>Kantor Gubernur Sumatera Selatan</td>
                            <td>Dibuka pada 20 September 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 09</div>
                            </td>
                            <td>Cinde</td>
                            <td>
                                <p>Trans Musi: Koridor 1, 6, 7 & 9 <br>Teman Bus: Koridor 1 & 3</p>
                            </td>
                            <td>Pasar Cinde</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 10</div>
                            </td>
                            <td>Ampera</td>
                            <td>
                                <p>Trans Musi: Koridor 1 & 3 <br>Teman Bus: Koridor 1</p>
                            </td>
                            <td>Jembatan Ampera, Pasar 16 Ilir, Benteng Kuto Besak</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 11</div>
                            </td>
                            <td>Polresta</td>
                            <td>
                                <p>Trans Musi: Koridor 9 <br>Teman Bus: Koridor 3 & 4F</p>
                            </td>
                            <td>Mapolresta Palembang, Kantor Pusat Bank Sumsel Babel</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 12</div>
                            </td>
                            <td>Jakabaring</td>
                            <td>
                                <p>Trans Musi: Koridor 9 <br>Teman Bus: -</p>
                            </td>
                            <td>Pasar Cinde</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="station-number">P 13</div>
                            </td>
                            <td>DJKA</td>
                            <td>
                                <p>Trans Musi: Koridor 9 <br>Teman Bus: Koridor 5F</p>
                            </td>
                            <td>OPI Mall, Perumahan Ogan Permata Indah</td>
                            <td>Dibuka pada 1 Agustus 2018</td>
                        </tr>

                    </table><br><br><br><br><br><br><br>
                    <!--<div class="button" style="text-align: center;  margin-top: -120px;">
                <br><a href="../beranda/beranda.html" style="font-size: 14px;"><button>Kembali ke Home</button></a>
            </div><br><br>-->

            <div class="footer-separator"></div>
            <div class="container1" style="font-family: Intim;">
                <div class="footer" style="font-size: 20px;">

                    <div class="contact-section">
                            <h2>KONTAK KAMI</h2>
                            <div class="contact-container">
                                <div class="contact-column">

                                    <!--Map-->
                                    <div class="contact-item">
                                        <a href="https://maps.app.goo.gl/pAXkCKnZRET83XRq6">
                                            <i class="fas fa-map-marker-alt"></i>
                                            </a>
                                        <div>
                                            <a href="https://maps.app.goo.gl/pAXkCKnZRET83XRq6">
                                            <strong>Kantor Pusat:</strong> 
                                            Jl. H.M. Noerdin Pandji, RT.11/RW.03, Jakabaring Selatan, Kec. Rambutan,
                                            Kab. Banyuasin, Sumatera Selatan 30967
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <!--Website-->
                                   <div class="contact-item">
                                        <a href="https://djka.dephub.go.id/">
                                            <i class="fas fa-globe"></i>
                                        </a>
                                        <div>
                                            <a href="https://djka.dephub.go.id/">
                                            <strong>Website:</strong> djka.dephub.go.id
                                            </a>
                                        </div>
                                    </div>

                                    <!--No Telepon-->
                                    <div class="contact-item">
                                        <a href="#">
                                            <i class="fas fa-phone"></i>
                                        </a>
                                        <div>
                                            <a href="#">
                                            <strong>No Telepon:</strong> 0711-5542499
                                            </a>
                                        </div>
                                    </div>

                                    <!--Email-->
                                    <div class="contact-item">
                                        <a href="../beranda/beranda1.html">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                        <div>
                                            <a href="../beranda/beranda1.html">
                                            <strong>Email:</strong> Balailrtsumsel@dephub.go.id
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <!--Instagram-->
                                <div class="contact-column">
                                    <div class="contact-item">
                                        <a href="https://www.instagram.com/lrtsumselofficial?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.instagram.com/lrtsumselofficial?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==">
                                            <strong>Instagram:</strong> @lrtsumselofficial
                                            </a>
                                        </div>
                                    </div>

                                    <!--Youtube-->
                                    <div class="contact-item">
                                        <a href="https://www.youtube.com/@lrtsumsel4659">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.youtube.com/@lrtsumsel4659">
                                            <strong>Youtube:</strong> @lrtsumsel4569
                                            </a>
                                        </div>
                                    </div>

                                    <!--Facebook-->
                                    <div class="contact-item">
                                        <a href="https://www.facebook.com/profile.php?id=100070323324622">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                        <div>
                                            <a href="https://www.facebook.com/profile.php?id=100070323324622">
                                            <strong>Facebook:</strong> @Balai Pengelola
                                            </a>
                                        </div>
                                    </div>

                                    <!--twitter-->
                                    <div class="contact-item">
                                        <a href="https://x.com/LrtSumsel">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                        <div>
                                            <a href="https://x.com/LrtSumsel">
                                            <strong>Twitter:</strong> @LrtSumsel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            

                    <script src="sejarah.js"></script>
</body>

</html>