<?php
session_start();
include '../kuisoner/config.php';

// Fungsi untuk mengunggah gambar
function uploadImage($imageName) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES[$imageName]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Periksa apakah file adalah gambar
    $check = getimagesize($_FILES[$imageName]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "<script>alert('File bukan gambar.');</script>";
        $uploadOk = 0;
    }

    // Periksa apakah file sudah ada
    if (file_exists($target_file)) {
        echo "<script>alert('Maaf, file sudah ada.');</script>";
        $uploadOk = 0;
    }


    // Batasi tipe file
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "<script>alert('Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.');</script>";
        $uploadOk = 0;
    }

    // Periksa apakah $uploadOk adalah 0
    if ($uploadOk == 0) {
        echo "<script>alert('Maaf, file Anda tidak diunggah.');</script>";
        return null;
    // jika semuanya baik-baik saja, coba unggah file
    } else {
        if (move_uploaded_file($_FILES[$imageName]["tmp_name"], $target_file)) {
            return $target_file;
        } else {
            echo "<script>alert('Maaf, terjadi kesalahan saat mengunggah file Anda.');</script>";
            return null;
        }
    }
}

// Tambah atau update data
if (isset($_POST['submit'])) {
    $pilihan = $_POST['pilihan'];
    $sejarah = $pilihan == 'sejarah' ? $_POST['sejarah'] : null;
    $visimisi = null;
    $struktur1 = null;
    $struktur2 = null;
    $struktur3 = null;

    if ($pilihan == 'visi dan misi') {
        $visimisi = uploadImage('visimisi');
    } elseif ($pilihan == 'struktur') {
        $struktur1 = uploadImage('struktur1');
        $struktur2 = uploadImage('struktur2');
        $struktur3 = uploadImage('struktur3');
    }

    if (isset($_POST['id_tentang']) && $_POST['id_tentang'] != '') {
        $id_tentang = $_POST['id_tentang'];
        $sql = "UPDATE tentang SET pilihan='$pilihan', sejarah='$sejarah', visimisi='$visimisi', struktur1='$struktur1', struktur2='$struktur2', struktur3='$struktur3' WHERE id_tentang='$id_tentang'";
    } else {
        $sql = "INSERT INTO tentang (pilihan, sejarah, visimisi, struktur1, struktur2, struktur3) VALUES ('$pilihan', '$sejarah', '$visimisi', '$struktur1', '$struktur2', '$struktur3')";
    }

    $conn->query($sql);
    echo "<script>alert('Data berhasil disimpan.');</script>";
    echo "<script>window.location.href='crud_tentang.php';</script>";
}

// Hapus data
if (isset($_GET['delete'])) {
    $id_tentang = $_GET['delete'];
    $sql = "DELETE FROM tentang WHERE id_tentang='$id_tentang'";
    $conn->query($sql);
    echo "<script>alert('Data berhasil dihapus.');</script>";
    echo "<script>window.location.href='crud_tentang.php';</script>";
}

// Ambil data untuk ditampilkan
$sql = "SELECT * FROM tentang";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kelola Tentang - Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../tentang kami/visimisi.css?v=1.0">
    <script>
        function showInputFields() {
            var pilihan = document.getElementById("pilihan").value;
            document.getElementById("input-sejarah").style.display = "none";
            document.getElementById("input-visimisi").style.display = "none";
            document.getElementById("input-struktur").style.display = "none";

            if (pilihan == "sejarah") {
                document.getElementById("input-sejarah").style.display = "block";
            } else if (pilihan == "visi dan misi") {
                document.getElementById("input-visimisi").style.display = "block";
            } else if (pilihan == "struktur") {
                document.getElementById("input-struktur").style.display = "block";
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            showInputFields();
        });

        function editTentang(id, pilihan, sejarah, visimisi, struktur1, struktur2, struktur3) {
            document.getElementById("id_tentang").value = id;
            document.getElementById("pilihan").value = pilihan;
            showInputFields();

            document.getElementById("sejarah").value = sejarah ? sejarah : '';
            document.getElementById("visimisi-display").src = visimisi ? visimisi : '';
            document.getElementById("struktur1-display").src = struktur1 ? struktur1 : '';
            document.getElementById("struktur2-display").src = struktur2 ? struktur2 : '';
            document.getElementById("struktur3-display").src = struktur3 ? struktur3 : '';
        }
    </script>
</head>
<body>

    <h2>Kelola Tentang</h2>

    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id_tentang" id="id_tentang">
        <label for="pilihan">Pilih Kategori:</label>
        <select name="pilihan" id="pilihan" onchange="showInputFields()">
            <option value="sejarah" selected>Sejarah</option>
            <option value="visi dan misi">Visi dan Misi</option>
            <option value="struktur">Struktur</option>
        </select>
        
        <div id="input-sejarah">
    <label for="sejarah">Sejarah:</label>
    <textarea name="sejarah" id="sejarah" cols="50" rows="10"></textarea>
</div>

        <div id="input-visimisi" style="display:none;">
            <label for="visimisi">Visi dan Misi:</label>
            <input type="file" name="visimisi" id="visimisi">
            <img id="visimisi-display" src="" alt="Visi Misi" style="display:block; max-width: 100px;">
        </div>

        <div id="input-struktur" style="display:none;">
            <label for="struktur1">Struktur 1:</label>
            <input type="file" name="struktur1" id="struktur1"><br>
            <img id="struktur1-display" src="" alt="Struktur 1" style="display:block; max-width: 100px;">
            <label for="struktur2">Struktur 2:</label>
            <input type="file" name="struktur2" id="struktur2"><br>
            <img id="struktur2-display" src="" alt="Struktur 2" style="display:block; max-width: 100px;">
            <label for="struktur3">Struktur 3:</label>
            <input type="file" name="struktur3" id="struktur3"><br>
            <img id="struktur3-display" src="" alt="Struktur 3" style="display:block; max-width: 100px;">
        </div>

        <button type="submit" name="submit" class="add-button">Simpan</button>
        </form>

<h2>Daftar Tentang</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Pilihan</th>
        <th>Sejarah</th>
        <th>Visi dan Misi</th>
        <th>Struktur 1</th>
        <th>Struktur 2</th>
        <th>Struktur 3</th>
        <th>Aksi</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['id_tentang']; ?></td>
        <td><?php echo $row['pilihan']; ?></td>
        <td><?php echo $row['sejarah']; ?></td>
        <td><?php echo $row['visimisi']; ?></td>
        <td><?php echo $row['struktur1']; ?></td>
        <td><?php echo $row['struktur2']; ?></td>
        <td><?php echo $row['struktur3']; ?></td>
        <td>
            <a href="#" onclick="editTentang('<?php echo $row['id_tentang']; ?>', '<?php echo $row['pilihan']; ?>', '<?php echo $row['sejarah']; ?>', '<?php echo $row['visimisi']; ?>', '<?php echo $row['struktur1']; ?>', '<?php echo $row['struktur2']; ?>', '<?php echo $row['struktur3']; ?>')">Edit</a>
            |
            <a href="crud_tentang.php?delete=<?php echo $row['id_tentang']; ?>" class="delete-link" onclick="return confirm('Apakah Anda yakin untuk menghapus data ini?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<br><br>

</body>
</html>