document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLeft = document.querySelector('.nav-left');
    const navRight = document.querySelector('.nav-right');

    menuToggle.addEventListener('click', function() {
        navLeft.classList.toggle('active');
        navRight.classList.toggle('active');
    });

    // Menutup menu saat item menu diklik
    const navItems = document.querySelectorAll('.nav-left a, .nav-right a');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            navLeft.classList.remove('active');
            navRight.classList.remove('active');
        });
    });

    // Menutup menu saat mengklik di luar navbar
    document.addEventListener('click', function(event) {
        const isClickInsideNav = navLeft.contains(event.target) || navRight.contains(event.target) || menuToggle.contains(event.target);
        if (!isClickInsideNav) {
            navLeft.classList.remove('active');
            navRight.classList.remove('active');
        }
    });
});
