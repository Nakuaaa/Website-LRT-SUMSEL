<?php
session_start();
include '../kuisoner/config.php'; // Pastikan file ini benar-benar terhubung ke database

function getExistingData() {
    global $conn;
    $query = "SELECT * FROM tentang LIMIT 1";
    $result = $conn->query($query);
    return $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'];
    $existingData = getExistingData();
    
    // Jika data belum ada, tambahkan baris baru dengan nilai default
    if (!$existingData) {
        $query = "INSERT INTO tentang (sejarah, visimisi, struktur1, struktur2, struktur3) VALUES (NULL, NULL, NULL, NULL, NULL)";
        $conn->query($query);
        $existingData = getExistingData(); // Ambil lagi data yang baru saja disisipkan
    }

    $id = $existingData['id_tentang'];

    if ($type == 'sejarah') {
        $sejarah = $_POST['sejarah'];
        $query = "UPDATE tentang SET sejarah='$sejarah' WHERE id_tentang=$id";
        $conn->query($query);
    } elseif ($type == 'visimisi') {
        $target_dir = "../kuisoner/uploads/";
        $visimisi = $target_dir . basename($_FILES["visimisi"]["name"]);
        move_uploaded_file($_FILES["visimisi"]["tmp_name"], $visimisi);

        $query = "UPDATE tentang SET visimisi='$visimisi' WHERE id_tentang=$id";
        $conn->query($query);
    } elseif ($type == 'struktur') {
        $target_dir = "../kuisoner/uploads/";
        $struktur1 = $target_dir . basename($_FILES["struktur1"]["name"]);
        $struktur2 = $target_dir . basename($_FILES["struktur2"]["name"]);
        $struktur3 = $target_dir . basename($_FILES["struktur3"]["name"]);

        move_uploaded_file($_FILES["struktur1"]["tmp_name"], $struktur1);
        move_uploaded_file($_FILES["struktur2"]["tmp_name"], $struktur2);
        move_uploaded_file($_FILES["struktur3"]["tmp_name"], $struktur3);

        $query = "UPDATE tentang SET struktur1='$struktur1', struktur2='$struktur2', struktur3='$struktur3' WHERE id_tentang=$id";
        $conn->query($query);
    }

    header('Location: crud_tentang.php');
    exit();
}

if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $query = "DELETE FROM tentang WHERE id_tentang=$id";
    $conn->query($query);

    header('Location: crud_tentang.php');
    exit();
}

$existingData = getExistingData();
$tabelDataQuery = "SELECT * FROM tentang";
$tabelDataResult = $conn->query($tabelDataQuery);
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD Tentang Kami</title>
    <link rel="stylesheet" type="text/css" href="style_crudtentang.css?v=1.0">

</head>
<body>
<div class="navbar">
<a href="crud_pertanyaan.php">Kelola Pertanyaan</a>
    <a href="crud_berita.php">Kelola Galeri</a>
    <a href="crud_tentang.php">Kelola Tentang</a>
    <a href="view_survey.php">Lihat Survey</a>
    <!--<a href="input_ikm.php">Input IKM</a>-->
    <a href="crud_kelPert.php">Kelola Kel Pertanyaan</a>
    <a href="crud_admin.php">Kelola Admin</a>
    <a href="../beranda/beranda1.html">Logout</a>
    </div>
    <div class="container">
        <h2>Sejarah</h2>
        <form method="post">
            <input type="hidden" name="type" value="sejarah">
            <textarea name="sejarah"><?php echo htmlspecialchars($existingData['sejarah']); ?></textarea>
            <button type="submit">Update Sejarah</button>
        </form>
        <hr>

        <h2>Visi Misi</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="type" value="visimisi">
            <input type="file" name="visimisi">
            <button type="submit">Upload Visi Misi</button>
        </form>
        <hr>

        <h2>Struktur Organisasi</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="type" value="struktur">
            <input type="file" name="struktur1">
            <input type="file" name="struktur2">
            <input type="file" name="struktur3">
            <button type="submit">Upload Struktur Organisasi</button>
        </form>

        <hr>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Sejarah</th>
                    <th>Visi Misi</th>
                    <th>Struktur 1</th>
                    <th>Struktur 2</th>
                    <th>Struktur 3</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $tabelDataResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_tentang']; ?></td>
                    <td><?php echo htmlspecialchars($row['sejarah']); ?></td>
                    <td><img src="<?php echo htmlspecialchars($row['visimisi']); ?>" width="100"></td>
                    <td><img src="<?php echo htmlspecialchars($row['struktur1']); ?>" width="100"></td>
                    <td><img src="<?php echo htmlspecialchars($row['struktur2']); ?>" width="100"></td>
                    <td><img src="<?php echo htmlspecialchars($row['struktur3']); ?>" width="100"></td>
                    <td><a href="crud_tentang.php?delete_id=<?php echo $row['id_tentang']; ?>">Delete</a></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
