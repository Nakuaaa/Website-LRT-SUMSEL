<?php
session_start();
include '../kuisoner/config.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Insert personal information into pelanggan table
  $jenis_kelamin = $_POST['jenis_kelamin'];
  $pekerjaan = $_POST['pekerjaan'];
  $usia = $_POST['usia'];
  $tujuan_perjalanan = $_POST['tujuan_perjalanan'];
  $frekuensi_penggunaan = $_POST['frekuensi_penggunaan'];

  $sql = "INSERT INTO pelanggan (jenis_kelamin, pekerjaan, usia, tujuan_perjalanan, frekuensi_penggunaan) VALUES ('$jenis_kelamin', '$pekerjaan', '$usia', '$tujuan_perjalanan', '$frekuensi_penggunaan')";
  $conn->query($sql);
  $id_pelanggan = $conn->insert_id; // Get the last inserted ID

  if (empty($id_pelanggan)) {
    echo "<script>alert('Error: id_pelanggan tidak tersedia.');</script>";
    echo "<script>window.location.href = 'index.html';</script>";
    exit;
  }

  // Insert survey answers into rating table
  foreach ($_POST['jawaban'] as $id_pertanyaan => $jawaban) {
    // Fetch question type and weight (bobot)
    $sql = "SELECT tipe_pertanyaan, opsi, bobot FROM pertanyaan WHERE id_pertanyaan = '$id_pertanyaan'";
    $result = $conn->query($sql);
    $question = $result->fetch_assoc();

    if (!$question) {
      echo "<script>alert('Error: id_pertanyaan tidak tersedia.');</script>";
      echo "<script>window.location.href = 'index.html';</script>";
      exit;
    }

    if ($question['tipe_pertanyaan'] == 'multiple choice' && isset($question['opsi'])) {
      // Find the option number
      $options = explode(',', $question['opsi']);
      $rating_value = array_search($jawaban, $options) + 1;
      $hasil_bobot = $rating_value * $question['bobot'];
      $sql = "INSERT INTO rating (id_pelanggan, id_pertanyaan, rating, hasil_bobot) VALUES ('$id_pelanggan', '$id_pertanyaan', '$rating_value', '$hasil_bobot')";
    } elseif ($question['tipe_pertanyaan'] == 'isian singkat') {
      $sql = "INSERT INTO rating (id_pelanggan, id_pertanyaan, isian) VALUES ('$id_pelanggan', '$id_pertanyaan', '$jawaban')";
    }
    $conn->query($sql);
  }

  echo "<script>alert('Survey berhasil dikirim!');</script>";
  echo "<script>window.location.href = '../survei/survei.php';</script>";
  exit;
}

// Fetch survey questions
$sql = "SELECT * FROM pertanyaan";
$result = $conn->query($sql);
$questions = [];
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Survey</title>
  <link rel="stylesheet" href="survei.css?v=1.0">
  <link rel="stylesheet" href="../beranda/beranda1.css">
  <link rel="stylesheet" href="survei1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap"
      rel="stylesheet"

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
</head>

<body>

<!-- bagian navbar -->
<header>
        <nav>
            <div class="nav-left" style="font-family: intim;">
                <a href="../beranda/beranda1.html">Beranda</a>
                <div class="dropdown">
                    <a href="#" <button class="dropbtn">Tentang Kami<span class="arrow-down"></span></button> </a>
                    <div class="dropdown-content">
                        <a href="../tentang kami/sejarah.php">Sejarah</a>
                        <a href="../tentang kami/visimisi.php">Visi dan Misi</a>
                        <a href="../tentang kami/struktur.php">Struktur</a>
                    </div>
                </div>
                <a href="../survei/survei.php" class="active">Survei</a>
                <a href="../Diagram/diagram.php">Diagram</a>
                <a href="../berita/berita.php">Galeri</a>
            </div>
            <div class="nav-right" style="font-family: intim;">
                <a href="../kuisoner/login.php" class="btn" target="_blank">Login Now</a>
            </div>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header>

  <div style="font-size: 24px;">
    <h2 style="text-align: center;" class="surveii">Survey</h2>
  </div>

  <form method="post" action="">
    <h2>Data Pribadi</h2>
    <label>Jenis Kelamin:</label>
    <select name="jenis_kelamin" required>
      <option value="laki-laki">Laki-laki</option>
      <option value="perempuan">Perempuan</option>
    </select><br>

    <label>Pekerjaan:</label>
    <select name="pekerjaan" required>
      <option value="Pelajar/Mahasiswa">Pelajar/Mahasiswa</option>
      <option value="Wiraswasta">Wiraswasta</option>
      <option value="PNS">PNS</option>
      <option value="lainnya">Lainnya</option>
    </select><br>

    <label>Usia:</label>
    <select name="usia" required>
      <option value="Anak-Anak (5-11 tahun)">Anak-Anak (5-11 tahun)</option>
      <option value="Remaja (12-25 tahun)">Remaja (12-25 tahun)</option>
      <option value="Dewasa (26-45 tahun)">Dewasa (26-45 tahun)</option>
      <option value="Lansia (46-65 tahun)">Lansia (46-65 tahun)</option>
    </select><br>

    <label>Tujuan Perjalanan:</label>
    <select name="tujuan_perjalanan" required>
      <option value="sekolah/kampus">Sekolah/Kampus</option>
      <option value="bekerja">Bekerja</option>
      <option value="jalan-jalan">Jalan-jalan</option>
      <option value="transit ke bandara">Transit ke Bandara</option>
    </select><br>

    <label>Frekuensi Penggunaan:</label>
    <select name="frekuensi_penggunaan" required>
      <option value="1 kali">1 kali</option>
      <option value="2-3 kali">2-3 kali</option>
      <option value=">3 kali">>3 kali</option>
    </select><br>

    <h2>Pertanyaan Survey</h2>
    <?php foreach ($questions as $question) : ?>
      <label><?php echo $question['pertanyaan']; ?></label><br>
      <?php if ($question['tipe_pertanyaan'] == 'isian singkat') : ?>
        <input type="text" name="jawaban[<?php echo $question['id_pertanyaan']; ?>]" required><br>
      <?php elseif ($question['tipe_pertanyaan'] == 'multiple choice' && isset($question['opsi'])) : ?>
        <?php $options = explode(',', $question['opsi']); ?>
        <?php foreach ($options as $index => $option) : ?>
          <div class="option">
            <input type="radio" name="jawaban[<?php echo $question['id_pertanyaan']; ?>]" value="<?php echo $option; ?>" required> <?php echo $option; ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
      <input type="hidden" name="id_pertanyaan" value="<?php echo $question['id_pertanyaan']; ?>">
      <br>
    <?php endforeach; ?>

    <input type="submit" value="Submit">
  </form>

  <script src="../tentang kami/sejarah.js"></script>
</body>

</html>