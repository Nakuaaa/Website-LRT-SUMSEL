<?php
session_start();
include 'config.php';

if (!isset($_SESSION['nama_admin'])) {
  header("Location: login.php");
  exit();
}

$items_per_page = 10; // Jumlah item per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Ambil data bulan yang tersedia untuk filter
$sql_bulan = "SELECT DISTINCT MONTH(waktu_submit) AS bulan FROM pelanggan";
$bulan_result = $conn->query($sql_bulan);

// Inisialisasi variabel untuk hasil filter
$bulan_selected = isset($_GET['bulan']) ? $_GET['bulan'] : null;

// Filter data berdasarkan bulan jika dipilih
$filter_sql = "";
if ($bulan_selected) {
  $filter_sql = "WHERE MONTH(pelanggan.waktu_submit) = " . $bulan_selected;
}

// Ambil data pelanggan berdasarkan filter bulan dan pagination
$sql_pelanggan = "SELECT * FROM pelanggan " . $filter_sql . " LIMIT $items_per_page OFFSET $offset";
$pelanggan = $conn->query($sql_pelanggan);

// Hitung total pelanggan untuk pagination
$sql_count = "SELECT COUNT(*) AS total FROM pelanggan " . $filter_sql;
$total_result = $conn->query($sql_count);
$total_pelanggan = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_pelanggan / $items_per_page);

// Ambil data pertanyaan beserta kelompoknya
$sql_pertanyaan = "SELECT p.*, k.kelompok 
                   FROM pertanyaan p
                   LEFT JOIN kel_pertanyaan k ON p.id_kel = k.id_kel";
$pertanyaan = $conn->query($sql_pertanyaan);

// Array untuk menyimpan pertanyaan berdasarkan ID dan kelompok
$pertanyaan_arr = [];
while ($row = $pertanyaan->fetch_assoc()) {
  $pertanyaan_arr[$row['kelompok']][] = [
    'id_pertanyaan' => $row['id_pertanyaan'],
    'pertanyaan' => $row['pertanyaan'],
    'tipe_pertanyaan' => $row['tipe_pertanyaan']
  ];
}

// Ambil data rating beserta waktu_submit (jika ada) berdasarkan filter bulan
$sql_rating = "SELECT rating.*, pelanggan.waktu_submit 
              FROM rating 
              LEFT JOIN pelanggan ON rating.id_pelanggan = pelanggan.id_pelanggan
              " . $filter_sql . " ORDER BY pelanggan.waktu_submit ASC";
$rating_result = $conn->query($sql_rating);

// Array untuk menyimpan jawaban pelanggan berdasarkan ID pelanggan
$rating_arr = [];
$waktu_submit = []; // Array untuk menyimpan waktu_submit
while ($row = $rating_result->fetch_assoc()) {
  $id_pelanggan = $row['id_pelanggan'];
  $id_pertanyaan = $row['id_pertanyaan'];
  
  if ($row['rating'] !== null) {
    $rating_arr[$id_pelanggan][$id_pertanyaan] = $row['rating'];
  } else {
    $rating_arr[$id_pelanggan][$id_pertanyaan] = $row['isian'];
  }
  
  // Simpan waktu submit jika ada
  if (isset($row['waktu_submit'])) {
    $waktu_submit[$id_pelanggan] = $row['waktu_submit'];
  }
}

// Hapus rating jika tombol hapus diklik
if (isset($_GET['delete_rating'])) {
  $id_pelanggan = $_GET['delete_rating'];

  // Hapus data rating untuk pelanggan tersebut
  $sql_delete = "DELETE FROM rating WHERE id_pelanggan='$id_pelanggan'";
  $conn->query($sql_delete);

  // Hapus data pelanggan (opsional, jika data pelanggan juga perlu dihapus)
  $sql_delete_pelanggan = "DELETE FROM pelanggan WHERE id_pelanggan='$id_pelanggan'";
  $conn->query($sql_delete_pelanggan);

  // Redirect ke halaman yang sama untuk merefresh data
  header("Location: view_survey.php?bulan=" . $bulan_selected . "&page=" . $page);
  exit();
}

// Export CSV jika tombol export diklik
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment;filename=hasil_survey.csv');

  $output = fopen('php://output', 'w');
  $header = ['ID Pelanggan', 'Jenis Kelamin', 'Pekerjaan', 'Usia', 'Tujuan Perjalanan', 'Waktu Submit', 'Frekuensi Penggunaan'];

  // Tambahkan header pertanyaan
  foreach ($pertanyaan_arr as $kelompok => $pertanyaan_group) {
    foreach ($pertanyaan_group as $pertanyaan) {
      $header[] = $pertanyaan['pertanyaan'];
    }
  }

  fputcsv($output, $header);

  // Ambil data pelanggan berdasarkan filter bulan
  $sql_pelanggan = "SELECT * FROM pelanggan " . $filter_sql;
  $pelanggan = $conn->query($sql_pelanggan);
  while ($row = $pelanggan->fetch_assoc()) {
    $data = [
      $row['id_pelanggan'],
      $row['jenis_kelamin'],
      $row['pekerjaan'],
      $row['usia'],
      $row['tujuan_perjalanan'],
      isset($waktu_submit[$row['id_pelanggan']]) ? $waktu_submit[$row['id_pelanggan']] : 'N/A',
      $row['frekuensi_penggunaan']
    ];

    // Tambahkan jawaban pelanggan
    foreach ($pertanyaan_arr as $kelompok => $pertanyaan_group) {
      foreach ($pertanyaan_group as $pertanyaan) {
        if (isset($rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']])) {
          if ($pertanyaan['tipe_pertanyaan'] == 'isian singkat') {
            $data[] = $rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']];
          } elseif ($pertanyaan['tipe_pertanyaan'] == 'multiple choice') {
            $data[] = $rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']];
          }
        } else {
          $data[] = 'N/A';
        }
      }
    }

    fputcsv($output, $data, ',', '"');
  }

  fclose($output);
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Survey - Admin Dashboard</title>
  <link rel="stylesheet" href="view_survey.css">
</head>

<body>
<div class="navbar">
<a href="crud_pertanyaan.php">Kelola Pertanyaan</a>
    <a href="crud_berita.php">Kelola Galeri</a>
    <a href="crud_tentang.php">Kelola Tentang</a>
    <a href="view_survey.php">Lihat Survey</a>
    <!--<a href="input_ikm.php">Input IKM</a>-->
    <a href="crud_kelPert.php">Kelola Kel Pertanyaan</a>
    <a href="crud_admin.php">Kelola Admin</a>
    <a href="../beranda/beranda1.html">Logout</a>
  </div>
  <h2>Hasil Survey</h2>
  <form method="get" action="">
    <label for="bulan">Pilih Bulan:</label>
    <select name="bulan" id="bulan">
      <option value="">Semua Bulan</option>
      <?php while ($bulan = $bulan_result->fetch_assoc()) : ?>
        <option value="<?php echo $bulan['bulan']; ?>" <?php echo ($bulan['bulan'] == $bulan_selected) ? 'selected' : ''; ?>>
          <?php echo date("F", mktime(0, 0, 0, $bulan['bulan'], 1)); ?>
        </option>
      <?php endwhile; ?>
    </select>
    <button type="submit">Filter</button>
    <button type="submit" name="export" value="csv">Export CSV</button>
  </form>
  
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th rowspan="2">Aksi</th>
          <th rowspan="2">ID Pelanggan</th>
          <th rowspan="2">Jenis Kelamin</th>
          <th rowspan="2">Pekerjaan</th>
          <th rowspan="2">Usia</th>
          <th rowspan="2">Tujuan Perjalanan</th>
          <th rowspan="2">Waktu Submit</th>
          <th rowspan="2">Frekuensi Penggunaan</th>
          <?php foreach ($pertanyaan_arr as $kelompok => $pertanyaan_group) : ?>
            <th colspan="<?php echo count($pertanyaan_group); ?>"><?php echo $kelompok; ?></th>
          <?php endforeach; ?>
        </tr>
        <tr>
          <?php foreach ($pertanyaan_arr as $kelompok => $pertanyaan_group) : ?>
            <?php foreach ($pertanyaan_group as $pertanyaan) : ?>
              <th><?php echo $pertanyaan['pertanyaan']; ?></th>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $pelanggan->fetch_assoc()) : ?>
          <tr>
            <td>
              <a href="?delete_rating=<?php echo $row['id_pelanggan']; ?>&bulan=<?php echo $bulan_selected; ?>&page=<?php echo $page; ?>" class="delete-link" onclick="return confirm('Apakah Anda yakin untuk menghapus rating pelanggan ini?')">Delete</a>
            </td>
            <td><?php echo $row['id_pelanggan']; ?></td>
            <td><?php echo $row['jenis_kelamin']; ?></td>
            <td><?php echo $row['pekerjaan']; ?></td>
            <td><?php echo $row['usia']; ?></td>
            <td><?php echo $row['tujuan_perjalanan']; ?></td>
            <td><?php echo isset($waktu_submit[$row['id_pelanggan']]) ? $waktu_submit[$row['id_pelanggan']] : 'N/A'; ?></td>
            <td><?php echo $row['frekuensi_penggunaan']; ?></td>
            <?php foreach ($pertanyaan_arr as $kelompok => $pertanyaan_group) : ?>
              <?php foreach ($pertanyaan_group as $pertanyaan) : ?>
                <td>
                  <?php
                  if (isset($rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']])) {
                    if ($pertanyaan['tipe_pertanyaan'] == 'isian singkat') {
                      echo $rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']];
                    } elseif ($pertanyaan['tipe_pertanyaan'] == 'multiple choice') {
                      echo $rating_arr[$row['id_pelanggan']][$pertanyaan['id_pertanyaan']];
                    }
                  } else {
                    echo 'N/A';
                  }
                  ?>
                </td>
              <?php endforeach; ?>
            <?php endforeach; ?>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <div class="pagination">
    <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
      <a href="?bulan=<?php echo $bulan_selected; ?>&page=<?php echo $i; ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>
  </div>

</body>

</html>

<?php
$conn->close();
?>